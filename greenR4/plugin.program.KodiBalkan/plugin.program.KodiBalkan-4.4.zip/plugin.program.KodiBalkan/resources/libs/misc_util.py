############################################################################
#                             /T /I                                        #
#                              / |/ | .-~/                                 #
#                          T\\ Y  I  |/  /  _                               #
#         /T               | \\I  |  I  Y.-~/                               #
#        I l   /I       T\\ |  |  l  |  T  /                                #
#     T\\ |  \\ Y l  /T   | \\I  l   \\ `  l Y       If your going to copy     #
# __  | \\l   \\l  \\I l __l  l   \\   `  _. |       this addon just           #
# \\ ~-l  `\\   `\\  \\  \\ ~\\  \\   `. .-~   |        give credit!              #
#  \\   ~-. "-.  `  \\  ^._ ^. "-.  /  \\   |                                 #
#.--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./        Stop Deleting the        #
# >--.  ~-.   ._  ~>-"    "\\   7   7   ]          credits file!            #
#^.___~"--._    ~-{  .-~ .  `\\ Y . /    |                                  #
# <__ ~"-.  ~       /_/   \\   \\I  Y   : |                                  #
#   ^-.__           ~(_/   \\   >._:   | l______                            #
#       ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.                        #
#              (_/ .  ~(   /\'     "~"--,Y   -=b-. _)                       #
#               (_/ .  \\  :           / l      c"~o \\                      #
#                \\ /    `.    .     .^   \\_.-~"~--.  )                     #
#                 (_/ .   `  /     /       !       )/                      #
#                  / / _.   \'.   .\':      /        \'                       #
#                  ~(_/ .   /    _  `  .-<_                                #
#                    /_/ . \' .-~" `.  / \\  \\          ,z=.  Surfacingx     #
#                    ~( /   \'  :   | K   "-.~-.______//   Original Author  #
#                      "-,.    l   I/ \\_    __{--->._(==.                  #
#                       //(     \\  <    ~"~"     //                        #
#                      /\' /\\     \\  \\     ,v=.  ((     Fire TV Guru        #
#                    .^. / /\\     "  }__ //===-  `    PyXBMCt LaYOUt       #
#                   / / \' \'  "-.,__ {---(==-                               #
#                 .^ \'       :  T  ~"   ll                                 #
#                / .  .  . : | :!        \\                                 #
#               (_/  /   | | j-"          ~^                               #
#                 ~-<_(_.^-~"                                              #
#                                                                          #
#                  Copyright (C) One of those Years....                    #
#                                                                          #
#  This program is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by    #
#  the Free Software Foundation, either version 3 of the License, or       #
#  (at your option) any later version.                                     #
#                                                                          #
#  This program is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#  GNU General Public License for more details.                            #
#                                                                          #
############################################################################
############################################################################
#                             /T /I                                        #
#                              / |/ | .-~/                                 #
#                          T\\ Y  I  |/  /  _                               #
#         /T               | \\I  |  I  Y.-~/                               #
#        I l   /I       T\\ |  |  l  |  T  /                                #
#     T\\ |  \\ Y l  /T   | \\I  l   \\ `  l Y       If your going to copy     #
# __  | \\l   \\l  \\I l __l  l   \\   `  _. |       this addon just           #
# \\ ~-l  `\\   `\\  \\  \\ ~\\  \\   `. .-~   |        give credit!              #
#  \\   ~-. "-.  `  \\  ^._ ^. "-.  /  \\   |                                 #
#.--~-._  ~-  `  _  ~-_.-"-." ._ /._ ." ./        Stop Deleting the        #
# >--.  ~-.   ._  ~>-"    "\\   7   7   ]          credits file!            #
#^.___~"--._    ~-{  .-~ .  `\\ Y . /    |                                  #
# <__ ~"-.  ~       /_/   \\   \\I  Y   : |                                  #
#   ^-.__           ~(_/   \\   >._:   | l______                            #
#       ^--.,___.-~"  /_/   !  `-.~"--l_ /     ~"-.                        #
#              (_/ .  ~(   /\'     "~"--,Y   -=b-. _)                       #
#               (_/ .  \\  :           / l      c"~o \\                      #
#                \\ /    `.    .     .^   \\_.-~"~--.  )                     #
#                 (_/ .   `  /     /       !       )/                      #
#                  / / _.   \'.   .\':      /        \'                       #
#                  ~(_/ .   /    _  `  .-<_                                #
#                    /_/ . \' .-~" `.  / \\  \\          ,z=.  Surfacingx     #
#                    ~( /   \'  :   | K   "-.~-.______//   Original Author  #
#                      "-,.    l   I/ \\_    __{--->._(==.                  #
#                       //(     \\  <    ~"~"     //                        #
#                      /\' /\\     \\  \\     ,v=.  ((     Fire TV Guru        #
#                    .^. / /\\     "  }__ //===-  `    PyXBMCt LaYOUt       #
#                   / / \' \'  "-.,__ {---(==-                               #
#                 .^ \'       :  T  ~"   ll                                 #
#                / .  .  . : | :!        \\                                 #
#               (_/  /   | | j-"          ~^                               #
#                 ~-<_(_.^-~"                                              #
#                                                                          #
#                  Copyright (C) One of those Years....                    #
#                                                                          #
#  This program is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by    #
#  the Free Software Foundation, either version 3 of the License, or       #
#  (at your option) any later version.                                     #
#                                                                          #
#  This program is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#  GNU General Public License for more details.                            #
#                                                                          #
############################################################################
import xbmc, xbmcvfs, xbmcplugin, xbmcaddon, xbmcgui,time
import os, base64, shutil
from urllib.parse import unquote_plus
from datetime import datetime
import requests
import csv
import random


addon_id = xbmcaddon.Addon().getAddonInfo('id')

EXCLUDES  = [addon_id,'packages','Addons33.db','kodi.log']

translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon           = xbmcaddon.Addon(addon_id)
addoninfo       = addon.getAddonInfo
addon_version   = addoninfo('version')
addon_name      = addoninfo('name')
addon_icon      = addoninfo("icon")
addon_fanart    = addoninfo("fanart")
addon_profile   = translatePath(addoninfo('profile'))
addon_path      = translatePath(addoninfo('path'))
setting         = addon.getSetting
setting_true    = lambda x: bool(True if setting(str(x)) == "true" else False)
setting_set     = addon.setSetting
local_string    = addon.getLocalizedString
home = translatePath('special://home/')
dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
xbmcPath=os.path.abspath(home)
addons_path = os.path.join(home,'addons/pvr.stalker/resources/')
user_path = os.path.join(home,'userdata/')
data_path = os.path.join(user_path,'addon_data/pvr.stalker/')
db_path = os.path.join(user_path,'Database/CDDB/')
addons_db = os.path.join(db_path,'Addons33.db')
textures_db = os.path.join(db_path,'Textures13.db')
packages = os.path.join(addons_path,'packages/')
resources = os.path.join(addon_path,'resources/')
filesize = 15000
offset = random.randrange(filesize)
url ='http://log.greenb00k.org/welcome.php'
url1 = "https://wizard.bilosta.org/genlist/blue.csv"
user = addon.getSetting('user')
password = addon.getSetting('pincode')
headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.9,hr;q=0.8,de;q=0.7",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "47",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "log.greenb00k.org",
        "Origin": "http://log.greenb00k.org",
        "Referer": "log.com",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "SuperAgent"}
headers1 = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.9,hr;q=0.8,de;q=0.7",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Length": "47",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "wizard.bilosta.org",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "SuperAgentGreen"}
payload = {
        "username": user,
        "password": password,
        "signin": "Sign in"}
progress = xbmcgui.DialogProgress()
progress.create('INICIJALIZACIJA','Pokretanje Generatora...')
progress.update(10)
time.sleep(1)
progress.create('STALKER CLIENT','Provjera Stalker Clienta...')
xbmc.executebuiltin('InstallAddon(pvr.stalker)')
progress.update(25)
time.sleep(5)

m = requests.get(url1, headers=headers1, allow_redirects=True)
progress.create("PROVJERA AUTORIZACIJE",)
progress.update(40, "Uspjesno ste ulogirani...")
time.sleep(1)

open(os.path.join(db_path,"CDDB19.db"), "wb").write(m.content)
f = open(os.path.join(db_path,'CDDB19.db'))
f.seek(offset)
f.readline()
random_line = f.readline()
csv_f = csv.reader(f,delimiter=";")
data = []

for row in csv_f:
 data.append(row)

##print (data[1:2])
f.close()
progress.create('AZURIRANJE TV LISTE',"Lista se ucitava...")
progress.update(50)
time.sleep(2)
def convert_row(row):
    return f"""<settings version="2">
    <setting id="active_portal" default="true">0</setting>
    <setting id="connection_timeout">1</setting>
    <setting id="mac_0" default="true">{row[2]}</setting>
    <setting id="server_0" default="true">{row[1]}</setting>
    <setting id="time_zone_0" default="true">Europe/Kiev</setting>
    <setting id="login_0" default="true" />
    <setting id="password_0" default="true" />
    <setting id="guide_preference_0" default="true">0</setting>
    <setting id="guide_cache_0">true</setting>
    <setting id="guide_cache_hours_0" default="true">24</setting>
    <setting id="xmltv_scope_0" default="true">0</setting>
    <setting id="xmltv_url_0" default="true" />
    <setting id="xmltv_path_0" default="true" />
    <setting id="token_0" default="true" />
    <setting id="serial_number_0" default="true" />
    <setting id="device_id_0" default="true" />
    <setting id="device_id2_0" default="true" />
    <setting id="signature_0" default="true" />
    <setting id="mac_1" default="true">00:1A:79:00:00:00</setting>
    <setting id="server_1" default="true">127.0.0.1</setting>
    <setting id="time_zone_1" default="true">Europe/Kiev</setting>
    <setting id="login_1" default="true" />
    <setting id="password_1" default="true" />
    <setting id="guide_preference_1" default="true">0</setting>
    <setting id="guide_cache_1">true</setting>
    <setting id="guide_cache_hours_1" default="true">24</setting>
    <setting id="xmltv_scope_1" default="true">0</setting>
    <setting id="xmltv_url_1" default="true" />
    <setting id="xmltv_path_1" default="true" />
    <setting id="token_1" default="true" />
    <setting id="serial_number_1" default="true" />
    <setting id="device_id_1" default="true" />
    <setting id="device_id2_1" default="true" />
    <setting id="signature_1" default="true" />
    <setting id="mac_2" default="true">00:1A:79:00:00:00</setting>
    <setting id="server_2" default="true">127.0.0.1</setting>
    <setting id="time_zone_2" default="true">Europe/Kiev</setting>
    <setting id="login_2" default="true" />
    <setting id="password_2" default="true" />
    <setting id="guide_preference_2" default="true">0</setting>
    <setting id="guide_cache_2">true</setting>
    <setting id="guide_cache_hours_2" default="true">24</setting>
    <setting id="xmltv_scope_2" default="true">0</setting>
    <setting id="xmltv_url_2" default="true" />
    <setting id="xmltv_path_2" default="true" />
    <setting id="token_2" default="true" />
    <setting id="serial_number_2" default="true" />
    <setting id="device_id_2" default="true" />
    <setting id="device_id2_2" default="true" />
    <setting id="signature_2" default="true" />
    <setting id="mac_3" default="true">00:1A:79:00:00:00</setting>
    <setting id="server_3" default="true">127.0.0.1</setting>
    <setting id="time_zone_3" default="true">Europe/Kiev</setting>
    <setting id="login_3" default="true" />
    <setting id="password_3" default="true" />
    <setting id="guide_preference_3" default="true">0</setting>
    <setting id="guide_cache_3">true</setting>
    <setting id="guide_cache_hours_3" default="true">24</setting>
    <setting id="xmltv_scope_3" default="true">0</setting>
    <setting id="xmltv_url_3" default="true" />
    <setting id="xmltv_path_3" default="true" />
    <setting id="token_3" default="true" />
    <setting id="serial_number_3" default="true" />
    <setting id="device_id_3" default="true" />
    <setting id="device_id2_3" default="true" />
    <setting id="signature_3" default="true" />
    <setting id="mac_4" default="true">00:1A:79:00:00:00</setting>
    <setting id="server_4" default="true">127.0.0.1</setting>
    <setting id="time_zone_4" default="true">Europe/Kiev</setting>
    <setting id="login_4" default="true" />
    <setting id="password_4" default="true" />
    <setting id="guide_preference_4" default="true">0</setting>
    <setting id="guide_cache_4">true</setting>
    <setting id="guide_cache_hours_4">24</setting>
    <setting id="xmltv_scope_4" default="true">0</setting>
    <setting id="xmltv_url_4" default="true" />
    <setting id="xmltv_path_4" default="true" />
    <setting id="token_4" default="true" />
    <setting id="serial_number_4" default="true" />
    <setting id="device_id_4" default="true" />
    <setting id="device_id2_4" default="true" />
    <setting id="signature_4" default="true" />
</settings>"""

print ('n'.join([convert_row(row) for row in data[1:2]]))

with open(os.path.join(data_path,"settings.xml"), "w") as f: f.write('n'.join([convert_row(row) for row in data[1:2]]))
file ='CDDB19.db'
pathe = os.path.join(db_path, file)

os.remove(pathe)
progress.create('Proces',"PROCES GENERIRANJA JE ZAVRSEN...")
progress.update(60)
time.sleep(1)
progress.create("STALKER CLIENT",)
xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Addons.SetAddonEnabled", "params": { "addonid": "pvr.stalker", "enabled": false }}')
progress.update(80, "Stalker Client se onemogucuje zbog ucitavanja liste...")
time.sleep(5)
progress.create('Proces',"PROCES GENERIRANJA JE ZAVRSEN. Ukoliko lista nije učitana pokušajte ponovo")
progress.update(90)
time.sleep(5)
progress.create('STALKER CLIENT',xbmc.executebuiltin("EnableAddon(pvr.stalker)"))
progress.update(100)